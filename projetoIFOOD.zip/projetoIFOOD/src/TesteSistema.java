public class TesteSistema {
    public static void main(String[] args) {
        System.out.println("=== TESTES UNITARIOS AUTOMATIZADOS ===");
        
        // Teste 1: Verificando se a matemática da distância está certa
        Restaurante r = new Restaurante("Teste", "Rua A", 0, 0);
        double dist = r.calcularDistancia(3, 4); // Triângulo 3-4-5 (Teorema de Pitágoras)
        
        if (dist == 5.0) System.out.println("[OK] Calculo de Distancia: APROVADO");
        else System.out.println("[X] Calculo de Distancia: FALHOU");
        
        // Teste 2: Verificando se o sistema barra preço negativo
        try {
            validar(-10); // Tenta passar um valor errado
            System.out.println("[X] Validacao de Erro: FALHOU (Deixou passar preco negativo)");
        } catch (Exception e) {
            System.out.println("[OK] Validacao de Erro: APROVADO (Detectou o erro: " + e.getMessage() + ")");
        }
    }
    
    static void validar(double p) throws Exception {
        if (p < 0) throw new Exception("Preco invalido");
    }
}