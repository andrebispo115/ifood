import javax.swing.*;
import java.awt.*;

public class TelaPrincipal extends JFrame {

    public TelaPrincipal() {
        setTitle("Sistema iFood Java - CESUPA");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1, 10, 10));

        JLabel lblBemVindo = new JLabel("Bem-vindo! Identifique-se:", SwingConstants.CENTER);
        lblBemVindo.setFont(new Font("Arial", Font.BOLD, 18));
        
        JButton btnSouDono = new JButton("Sou Dono de Restaurante");
        JButton btnSouCliente = new JButton("Sou Cliente");
        JButton btnSair = new JButton("Sair");

        add(lblBemVindo);
        add(btnSouDono);
        add(btnSouCliente);
        add(btnSair);

        // --- AÇÃO DO DONO ---
        btnSouDono.addActionListener(e -> {
            String[] opcoes = {"Fazer Login", "Cadastrar Nova Conta"};
            int escolha = JOptionPane.showOptionDialog(this, "Você já tem cadastro?", "Acesso Dono",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opcoes, opcoes[0]);

            if (escolha == 0) {
                // FLUXO LOGIN
                fazerLoginDono();
            } else if (escolha == 1) {
                // FLUXO CADASTRO
                cadastrarNovoDono();
            }
        });

        // --- AÇÃO DO CLIENTE ---
        btnSouCliente.addActionListener(e -> {
            String[] opcoes = {"Fazer Login", "Cadastrar Nova Conta"};
            int escolha = JOptionPane.showOptionDialog(this, "Você já tem cadastro?", "Acesso Cliente",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opcoes, opcoes[0]);

            if (escolha == 0) {
                fazerLoginCliente();
            } else if (escolha == 1) {
                cadastrarNovoCliente();
            }
        });

        btnSair.addActionListener(e -> System.exit(0));
    }

    // =================================================================================
    // MÉTODOS DE LOGIN (SEGURANÇA E REDIRECIONAMENTO)
    // =================================================================================

    private void fazerLoginDono() {
        String[] credenciais = exibirFormularioLogin("Login - Dono");
        if (credenciais == null) return; // Cancelou

        Usuario u = buscarUsuario(credenciais[0], credenciais[1]);

        if (u != null) {
            // Verifica se o usuário achado é realmente um Dono
            if (u instanceof DonoRestaurante) {
                DadosGlobais.usuarioLogado = u;
                // SEGURANÇA: Abre direto a tela DESTE dono, sem pedir para escolher restaurante
                new TelaDono().setVisible(true); 
            } else {
                JOptionPane.showMessageDialog(this, "Este email pertence a um Cliente, não a um Dono!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Email ou senha incorretos (ou usuário não cadastrado).");
        }
    }

    private void fazerLoginCliente() {
        String[] credenciais = exibirFormularioLogin("Login - Cliente");
        if (credenciais == null) return;

        Usuario u = buscarUsuario(credenciais[0], credenciais[1]);

        if (u != null) {
            if (u instanceof Cliente) {
                DadosGlobais.usuarioLogado = u;
                new TelaCliente().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Este email pertence a um Dono, não a um Cliente!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Email ou senha incorretos.");
        }
    }

    // Busca na lista global se existe alguém com esse email E senha
    private Usuario buscarUsuario(String email, String senha) {
        for (Usuario u : DadosGlobais.usuariosCadastrados) {
            // Comparação de Strings deve usar .equals()
            if (u.getEmail().equals(email) && u.getSenha().equals(senha)) {
                return u;
            }
        }
        return null; // Não achou ninguém
    }

    // =================================================================================
    // MÉTODOS DE CADASTRO (CRIAR NOVOS)
    // =================================================================================

    private void cadastrarNovoDono() {
        String[] dados = exibirFormularioCadastro("Novo Cadastro - Dono");
        if (dados == null) return;

        String email = dados[0];
        String senha = dados[1];
        String nome = email.split("@")[0]; // Usa parte do email como nome provisório

        // Verifica se email já existe
        if (emailJaExiste(email)) {
            JOptionPane.showMessageDialog(this, "Erro: Este email já está cadastrado!");
            return;
        }

        // Se é novo dono, OBRIGATORIAMENTE cadastra o restaurante agora
        cadastrarRestauranteParaODono(nome, email, senha);
    }

    private void cadastrarNovoCliente() {
        String[] dados = exibirFormularioCadastro("Novo Cadastro - Cliente");
        if (dados == null) return;

        String email = dados[0];
        String senha = dados[1];
        String nome = email.split("@")[0];

        if (emailJaExiste(email)) {
            JOptionPane.showMessageDialog(this, "Erro: Este email já está cadastrado!");
            return;
        }

        // Cria o cliente e salva na lista global
        Cliente novoCliente = new Cliente(nome, email, senha);
        DadosGlobais.usuariosCadastrados.add(novoCliente);
        DadosGlobais.usuarioLogado = novoCliente;
        
        JOptionPane.showMessageDialog(this, "Cadastro realizado com sucesso!");
        new TelaCliente().setVisible(true);
    }

    private boolean emailJaExiste(String email) {
        for (Usuario u : DadosGlobais.usuariosCadastrados) {
            if (u.getEmail().equals(email)) return true;
        }
        return false;
    }

    // =================================================================================
    // MÉTODOS AUXILIARES E UI
    // =================================================================================

    private void cadastrarRestauranteParaODono(String nomeDono, String email, String senha) {
        JTextField txtNome = new JTextField();
        JTextField txtEndereco = new JTextField();
        JTextField txtX = new JTextField("0");
        JTextField txtY = new JTextField("0");

        Object[] message = {
            "--- Dados do seu Restaurante ---",
            "Nome do Restaurante:", txtNome,
            "Endereço:", txtEndereco,
            "Localização X:", txtX,
            "Localização Y:", txtY
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Cadastrando Restaurante", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String nomeRes = txtNome.getText();
                String endereco = txtEndereco.getText();
                int x = Integer.parseInt(txtX.getText());
                int y = Integer.parseInt(txtY.getText());

                if (!nomeRes.isEmpty() && !endereco.isEmpty()) {
                    Restaurante novoRestaurante = new Restaurante(nomeRes, endereco, x, y);
                    
                    // Salva o restaurante na lista global (para clientes verem)
                    DadosGlobais.restaurantes.add(novoRestaurante);
                    
                    // Cria o Dono vinculado a ESTE restaurante
                    DonoRestaurante novoDono = new DonoRestaurante(nomeDono, email, senha, novoRestaurante);
                    
                    // Salva o Dono na lista de usuários (para login futuro)
                    DadosGlobais.usuariosCadastrados.add(novoDono);
                    DadosGlobais.usuarioLogado = novoDono;

                    JOptionPane.showMessageDialog(this, "Conta e Restaurante criados com sucesso!");
                    new TelaDono().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Preencha o nome e endereço!");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Coordenadas inválidas!");
            }
        }
    }

    private String[] exibirFormularioLogin(String titulo) {
        return exibirPopupEmailSenha(titulo, false); // false = não valida existência, pois é login
    }

    private String[] exibirFormularioCadastro(String titulo) {
        return exibirPopupEmailSenha(titulo, true); // true = valida regras de cadastro
    }

    private String[] exibirPopupEmailSenha(String titulo, boolean ehCadastro) {
        JTextField txtEmail = new JTextField();
        JPasswordField txtSenha = new JPasswordField();
        
        Object[] message = {
            "Email (@gmail.com):", txtEmail,
            "Senha:", txtSenha
        };

        int option = JOptionPane.showConfirmDialog(this, message, titulo, JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String email = txtEmail.getText().trim();
            String senha = new String(txtSenha.getPassword());

            if (email.isEmpty() || senha.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
                return null;
            }
            
            if (!email.endsWith("@gmail.com")) {
                JOptionPane.showMessageDialog(this, "O email deve terminar com @gmail.com");
                return null;
            }

            return new String[]{email, senha};
        }
        return null;
    }

    // --- MAIN AGORA ESTÁ LIMPO ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaPrincipal().setVisible(true));
    }
}