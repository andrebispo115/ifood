import java.util.Random;

public abstract class Usuario {
    protected String id; // Novo campo ID
    protected String nome;
    protected String email;
    protected String senha; // Novo campo Senha

    public Usuario(String nome, String email, String senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.id = gerarIdUnico(); // Gera ID ao criar
    }
    
    // Método para gerar um ID aleatório (Ex: #8492)
    private String gerarIdUnico() {
        Random rand = new Random();
        int numero = rand.nextInt(9000) + 1000; 
        return "#" + numero;
    }

    public String getNome() { return nome; }
    public String getId() { return id; }

    // Na classe Usuario.java
public String getEmail() { return email; }
public String getSenha() { return senha; }
}